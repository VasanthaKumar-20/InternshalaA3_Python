def bat():
    '''runs=p(i)["runs"]
    balls=p(i)["balls"]
    field=p(i)["field"]
    f=p(i)["4"]
    s=p(i)["6"]'''
    sr=(runs/balls)*100
    
    p=(runs/2)+f+(2*s)+field
    
    if(runs>=50):
         p=p+5
    elif(runs>=100):
         p=p+10
    else:
         p=p+0

    if(sr>=100):
         p=p+4
    elif(sr>80):
         p=p+2
    else:
         p=p+0
    print("{'name':",name,"'batscore':",p,"}")

def ball():
    '''wic=p(i)["wkts"]
    overs=p(i)["overs"]
    runs=p(i)["runs"]
    field=p(i)["field"]'''
    eco=runs/overs
    balls=overs*6
    p=(10*wic)+field*10
    if(wic>=5):
        p=p+10
    elif(wic>=3):
        p=p+5
    else:
        p=p+0
    if(eco<2):
        p=p+10  
    elif(eco<3.5):
        p=p+7
    elif(eco<4.5):
        p=p+4
    else:
        p=p+0
    print("{'name':",name,"'bowlscore':",p,"}")

for x in range(5):
    name=(p[x]["name"])

    role=p[x]["role"]
    if(role=='bat'):
        runs=p[x]["runs"]
        balls=p[x]["balls"]
        field=p[x]["field"]
        f=p[x]["4"]
        s=p[x]["6"]
        bat()
    else:
        wic=p[x]["wkts"]
        overs=p[x]["overs"]
        runs=p[x]["runs"]
        field=p[x]["field"]
        ball()


