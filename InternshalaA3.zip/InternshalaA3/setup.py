from setuptools import setup

setup(name='InternshalaA3', version='1.0', description='A package to calculate expenses when you hang-out with friends.',
url='#',
      author='internshala',
author_email='internshala@internshala.com',
      license='MIT',
      packages=['InternshalaA3'],
zip_safe=False)
